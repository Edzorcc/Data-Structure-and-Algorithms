public class BinaryTree {
    Node root;

    /* Hàm đệ quy để đếm số lượng các nút chỉ có một con */
    int countOneChildNodes(Node node) {
        // Nếu cây rỗng hoặc là nút lá
        if (node == null || (node.left == null && node.right == null))
            return 0;

        // Nếu nút chỉ có một con
        if (node.left == null || node.right == null)
            return 1 + countOneChildNodes(node.left) + countOneChildNodes(node.right);

        // Nếu nút có cả hai con
        return countOneChildNodes(node.left) + countOneChildNodes(node.right);
    }
}
